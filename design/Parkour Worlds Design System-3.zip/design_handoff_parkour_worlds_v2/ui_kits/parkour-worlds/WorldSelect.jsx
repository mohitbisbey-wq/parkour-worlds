/* global React, Starfield, WorldCard, WORLDS, Emblem, EMBLEM_KIND */

function WorldSelect({ onPlayLevel, onBack }) {
  return (
    <div className="pw-scene pw-worldselect">
      <Starfield density={55} />
      <h2>CHOOSE YOUR WORLD</h2>
      <div className="grid">
        {WORLDS.slice(0,5).map((_, wi) => (
          <WorldCard key={wi} wi={wi} onPlayLevel={onPlayLevel} />
        ))}
      </div>
      <div className="pw-practice" onClick={() => onPlayLevel(5, 0)}>
        <Emblem kind="target" size={16} />
        <span>Test Zone&nbsp;&nbsp;—&nbsp;&nbsp;practice</span>
      </div>
      <div className="ctrl-hint">
        WASD / Arrows&nbsp;&nbsp;move&nbsp;&nbsp;·&nbsp;&nbsp;Space&nbsp;&nbsp;jump&nbsp;&nbsp;·&nbsp;&nbsp;Push wall + jump&nbsp;&nbsp;=&nbsp;&nbsp;wall jump
      </div>
      <div className="esc" onClick={onBack} style={{ cursor: 'pointer' }}>ESC = back</div>
    </div>
  );
}

window.WorldSelect = WorldSelect;
