/* global React, fmt */

function LevelCompleteModal({ runMs, bestTimes, runRank, deaths, coinsCollected, coinsTotal, onNext, onBack }) {
  return (
    <div className="pw-modal-shade">
      <div className="pw-modal">
        <div className="pw-modal-h">Level Complete!</div>
        <div className="pw-modal-time">{fmt(runMs)}</div>
        {runRank === 0 && <div className="pw-modal-new">★ New Best! #1</div>}
        {runRank === 1 && <div className="pw-modal-new silver">★ Top 3 · #2</div>}
        {runRank === 2 && <div className="pw-modal-new bronze">★ Top 3 · #3</div>}
        {runRank < 0 && <div className="pw-modal-new mute">not a top 3 time</div>}
        <hr/>
        <div className="pw-modal-lbl">BEST TIMES</div>
        <div className="pw-modal-best">
          {[0,1,2].map(i => {
            const time = bestTimes[i];
            const isYou = i === runRank;
            const cls = ['gold','silver','bronze'][i] + (isYou ? ' active' : '');
            return (
              <div key={i} className={'pw-modal-row ' + cls}>
                <span className="rank">#{i+1}</span>
                <span className="time">{time != null ? fmt(time) : '—:——.——'}</span>
                <span className="cursor">{isYou ? '◀' : ''}</span>
              </div>
            );
          })}
        </div>
        <hr/>
        <div className="pw-modal-stats">
          <span className="skull">☠ {deaths} death{deaths !== 1 ? 's' : ''}</span>
          <span className="gold">{coinsCollected}/{coinsTotal} coins</span>
        </div>
        <div className="pw-modal-next" onClick={onNext}>SPACE → next level</div>
        <div className="pw-modal-esc"  onClick={onBack}>ESC → world select</div>
      </div>
    </div>
  );
}

window.LevelCompleteModal = LevelCompleteModal;
