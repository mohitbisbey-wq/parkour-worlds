/* global React, WORLDS, PlayerSprite, CoinSprite, ChestSprite, FlagSprite, EnemySprite */

const { useState, useEffect } = React;

// WorldStage — a non-interactive recreation of the in-game playfield.
// Renders the sky + floor + a small set of platforms and sprites
// (player, coin, flag, chest, enemy) so the HUD has live-looking context.
function WorldStage({ worldIndex }) {
  const wd = WORLDS[worldIndex];
  return (
    <div className="pw-stage" style={{ background: `linear-gradient(${wd.bg[0]}, ${wd.bg[1]})` }}>
      <div className="pw-floor" style={{ background: wd.bot }} />
      {/* a few placeholder platforms, varied by world */}
      <div className="pw-plat" style={{ left: 60,  bottom: 56,  width: 110, '--body': platformColors[worldIndex][0], '--cap': platformColors[worldIndex][1] }} />
      <div className="pw-plat" style={{ left: 220, bottom: 102, width: 90,  '--body': platformColors[worldIndex][0], '--cap': platformColors[worldIndex][1] }} />
      <div className="pw-plat" style={{ left: 360, bottom: 140, width: 90,  '--body': platformColors[worldIndex][0], '--cap': platformColors[worldIndex][1] }} />
      <div className="pw-plat" style={{ left: 500, bottom: 178, width: 120, '--body': platformColors[worldIndex][0], '--cap': platformColors[worldIndex][1] }} />
      <div className="pw-plat" style={{ left: 670, bottom: 220, width: 100, '--body': platformColors[worldIndex][0], '--cap': platformColors[worldIndex][1] }} />

      {/* coins (bobbing) */}
      <div className="pw-sprite" style={{ left: 100, bottom: 80  }}><CoinSprite scale={1.4}/></div>
      <div className="pw-sprite" style={{ left: 250, bottom: 126 }}><CoinSprite scale={1.4}/></div>
      <div className="pw-sprite" style={{ left: 390, bottom: 164 }}><CoinSprite scale={1.4}/></div>
      <div className="pw-sprite" style={{ left: 550, bottom: 202 }}><CoinSprite scale={1.4}/></div>

      {/* flag */}
      <div className="pw-sprite" style={{ left: 405, bottom: 196 }}><FlagSprite triggered scale={1.6}/></div>

      {/* chest at the end */}
      <div className="pw-sprite" style={{ left: 690, bottom: 246 }}><ChestSprite scale={1.6}/></div>

      {/* enemy patrolling lower platform */}
      <div className="pw-sprite" style={{ left: 270, bottom: 128 }}><EnemySprite worldIndex={worldIndex} scale={1.6}/></div>

      {/* player standing on the starting block */}
      <div className="pw-sprite" style={{ left: 90,  bottom: 82  }}><PlayerSprite scale={1.6}/></div>
    </div>
  );
}

// per-world platform color (body, cap)
const platformColors = [
  ['#7a5c12', '#9a7520'],
  ['#1e1c2a', '#c62828'],
  ['#8b6030', '#c8a060'],
  ['#0e4a3a', '#20b090'],
  ['#1a0808', '#ff3d00'],
  ['#3a3a3a', '#aaaaaa'],
];

window.WorldStage = WorldStage;
