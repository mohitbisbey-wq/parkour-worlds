/* global React */

// Pixel-art world emblems. Each is a 16×16 grid of <rect>s in a 16-unit viewBox.
// Same designs as preview/world-emblems.html — kept here so they travel with the kit.
function Emblem({ kind, size = 26 }) {
  const props = { width: size, height: size, viewBox: '0 0 16 16', shapeRendering: 'crispEdges' };
  switch (kind) {
    case 'anchor': return (
      <svg {...props}>
        <rect x="0"  y="13" width="2" height="2" fill="#9bd0ff"/>
        <rect x="2"  y="14" width="3" height="2" fill="#9bd0ff"/>
        <rect x="5"  y="13" width="2" height="2" fill="#9bd0ff"/>
        <rect x="7"  y="14" width="3" height="2" fill="#9bd0ff"/>
        <rect x="10" y="13" width="2" height="2" fill="#9bd0ff"/>
        <rect x="12" y="14" width="4" height="2" fill="#9bd0ff"/>
        <rect x="6" y="0" width="4" height="1" fill="#fff"/>
        <rect x="5" y="1" width="1" height="2" fill="#fff"/>
        <rect x="10" y="1" width="1" height="2" fill="#fff"/>
        <rect x="6" y="3" width="4" height="1" fill="#fff"/>
        <rect x="7" y="4" width="2" height="7" fill="#fff"/>
        <rect x="4" y="5" width="8" height="1" fill="#fff"/>
        <rect x="3" y="9"  width="1" height="1" fill="#fff"/>
        <rect x="3" y="10" width="1" height="1" fill="#fff"/>
        <rect x="4" y="11" width="2" height="1" fill="#fff"/>
        <rect x="12" y="9"  width="1" height="1" fill="#fff"/>
        <rect x="12" y="10" width="1" height="1" fill="#fff"/>
        <rect x="10" y="11" width="2" height="1" fill="#fff"/>
        <rect x="6" y="11" width="4" height="1" fill="#fff"/>
      </svg>
    );
    case 'shuriken': return (
      <svg {...props}>
        <rect x="7" y="0"  width="2" height="6" fill="#3a2440"/>
        <rect x="7" y="10" width="2" height="6" fill="#3a2440"/>
        <rect x="0" y="7"  width="6" height="2" fill="#3a2440"/>
        <rect x="10" y="7" width="6" height="2" fill="#3a2440"/>
        <rect x="7" y="0"  width="1" height="6" fill="#fff"/>
        <rect x="0" y="7"  width="6" height="1" fill="#fff"/>
        <rect x="7" y="10" width="1" height="6" fill="#fff"/>
        <rect x="10" y="7" width="6" height="1" fill="#fff"/>
        <rect x="6" y="6" width="4" height="4" fill="#CE93D8"/>
        <rect x="7" y="7" width="2" height="2" fill="#fff"/>
      </svg>
    );
    case 'cactus': return (
      <svg {...props}>
        <rect x="2" y="6"  width="2" height="1" fill="#3a8c2a"/>
        <rect x="2" y="7"  width="2" height="3" fill="#3a8c2a"/>
        <rect x="3" y="10" width="1" height="1" fill="#3a8c2a"/>
        <rect x="12" y="4" width="2" height="1" fill="#3a8c2a"/>
        <rect x="12" y="5" width="2" height="3" fill="#3a8c2a"/>
        <rect x="12" y="8" width="1" height="1" fill="#3a8c2a"/>
        <rect x="6" y="3"  width="4" height="11" fill="#3a8c2a"/>
        <rect x="6" y="3"  width="1" height="11" fill="#6ec044"/>
        <rect x="2" y="6"  width="1" height="4"  fill="#6ec044"/>
        <rect x="12" y="4" width="1" height="4"  fill="#6ec044"/>
        <rect x="9" y="3"  width="1" height="11" fill="#1d5d18"/>
        <rect x="3" y="14" width="10" height="1" fill="#c8a060"/>
        <rect x="4" y="15" width="8"  height="1" fill="#8b6030"/>
        <rect x="7" y="2"  width="2" height="1" fill="#ff7043"/>
        <rect x="13" y="3" width="1" height="1" fill="#ff7043"/>
      </svg>
    );
    case 'shell': return (
      <svg {...props}>
        <rect x="5" y="1" width="6" height="1" fill="#fff"/>
        <rect x="3" y="2" width="2" height="2" fill="#fff"/>
        <rect x="11" y="2" width="2" height="2" fill="#fff"/>
        <rect x="2" y="4" width="1" height="5" fill="#fff"/>
        <rect x="13" y="4" width="1" height="5" fill="#fff"/>
        <rect x="3" y="9" width="2" height="1" fill="#fff"/>
        <rect x="13" y="9" width="1" height="1" fill="#fff"/>
        <rect x="4" y="10" width="2" height="1" fill="#fff"/>
        <rect x="13" y="10" width="2" height="1" fill="#fff"/>
        <rect x="5" y="11" width="2" height="1" fill="#fff"/>
        <rect x="13" y="11" width="2" height="1" fill="#fff"/>
        <rect x="6" y="12" width="2" height="1" fill="#fff"/>
        <rect x="12" y="12" width="2" height="1" fill="#fff"/>
        <rect x="7" y="13" width="6" height="1" fill="#fff"/>
        <rect x="5" y="2" width="6" height="1" fill="#ffe9c2"/>
        <rect x="4" y="3" width="8" height="1" fill="#ffe9c2"/>
        <rect x="3" y="4" width="10" height="5" fill="#ffe9c2"/>
        <rect x="3" y="9" width="10" height="1" fill="#ffe9c2"/>
        <rect x="4" y="10" width="9" height="1" fill="#ffe9c2"/>
        <rect x="5" y="11" width="8" height="1" fill="#ffe9c2"/>
        <rect x="6" y="12" width="6" height="1" fill="#ffe9c2"/>
        <rect x="4" y="4" width="8" height="1" fill="#ff9b6b"/>
        <rect x="3" y="6" width="10" height="1" fill="#ff9b6b"/>
        <rect x="3" y="8" width="9" height="1" fill="#ff9b6b"/>
        <rect x="5" y="10" width="6" height="1" fill="#ff9b6b"/>
        <rect x="6" y="5" width="4" height="3" fill="#80DEEA"/>
        <rect x="7" y="6" width="2" height="1" fill="#fff"/>
        <rect x="12" y="9" width="1" height="3" fill="#ff7043"/>
      </svg>
    );
    case 'flame': return (
      <svg {...props}>
        <rect x="7"  y="1"  width="2"  height="1" fill="#ff3d00"/>
        <rect x="6"  y="2"  width="4"  height="1" fill="#ff3d00"/>
        <rect x="5"  y="3"  width="6"  height="1" fill="#ff3d00"/>
        <rect x="4"  y="4"  width="2"  height="2" fill="#ff3d00"/>
        <rect x="10" y="4"  width="2"  height="2" fill="#ff3d00"/>
        <rect x="4"  y="6"  width="1"  height="3" fill="#ff3d00"/>
        <rect x="11" y="6"  width="1"  height="3" fill="#ff3d00"/>
        <rect x="3"  y="9"  width="10" height="3" fill="#ff3d00"/>
        <rect x="4"  y="12" width="8"  height="1" fill="#ff3d00"/>
        <rect x="5"  y="13" width="6"  height="1" fill="#ff3d00"/>
        <rect x="7"  y="4"  width="2"  height="1" fill="#FF7043"/>
        <rect x="6"  y="5"  width="4"  height="1" fill="#FF7043"/>
        <rect x="5"  y="6"  width="6"  height="3" fill="#FF7043"/>
        <rect x="6"  y="9"  width="4"  height="3" fill="#FF7043"/>
        <rect x="7"  y="7"  width="2"  height="3" fill="#FFD700"/>
        <rect x="7"  y="6"  width="1"  height="1" fill="#FFD700"/>
        <rect x="7"  y="10" width="2"  height="1" fill="#FFD700"/>
        <rect x="1"  y="6"  width="1"  height="1" fill="#FFD700"/>
        <rect x="14" y="8"  width="1"  height="1" fill="#FFD700"/>
        <rect x="2"  y="11" width="1"  height="1" fill="#ff3d00"/>
      </svg>
    );
    case 'target': return (
      <svg {...props}>
        <rect x="4" y="2" width="8" height="1" fill="#fff"/>
        <rect x="2" y="4" width="2" height="2" fill="#fff"/>
        <rect x="12" y="4" width="2" height="2" fill="#fff"/>
        <rect x="1" y="6" width="1" height="4" fill="#fff"/>
        <rect x="14" y="6" width="1" height="4" fill="#fff"/>
        <rect x="2" y="10" width="2" height="2" fill="#fff"/>
        <rect x="12" y="10" width="2" height="2" fill="#fff"/>
        <rect x="4" y="13" width="8" height="1" fill="#fff"/>
        <rect x="4" y="3" width="8" height="1" fill="#c62828"/>
        <rect x="3" y="4" width="10" height="1" fill="#c62828"/>
        <rect x="2" y="5" width="12" height="1" fill="#c62828"/>
        <rect x="2" y="10" width="12" height="1" fill="#c62828"/>
        <rect x="3" y="11" width="10" height="1" fill="#c62828"/>
        <rect x="4" y="12" width="8" height="1" fill="#c62828"/>
        <rect x="3" y="6" width="10" height="1" fill="#fff"/>
        <rect x="2" y="6" width="1" height="4" fill="#fff"/>
        <rect x="13" y="6" width="1" height="4" fill="#fff"/>
        <rect x="3" y="9" width="10" height="1" fill="#fff"/>
        <rect x="3" y="7" width="10" height="2" fill="#c62828"/>
        <rect x="5" y="6" width="6" height="4" fill="#ff7043"/>
        <rect x="6" y="7" width="4" height="2" fill="#FFD700"/>
        <rect x="7" y="7" width="2" height="2" fill="#fff"/>
        <rect x="9"  y="6" width="3" height="1" fill="#222"/>
        <rect x="11" y="5" width="2" height="1" fill="#222"/>
        <rect x="12" y="4" width="2" height="1" fill="#FFD700"/>
      </svg>
    );
    default: return null;
  }
}

// Map worldIndex → emblem kind
const EMBLEM_KIND = ['anchor', 'shuriken', 'cactus', 'shell', 'flame', 'target'];

window.Emblem = Emblem;
window.EMBLEM_KIND = EMBLEM_KIND;
