/* global React, WORLDS, EMBLEM_KIND, Emblem, fmt */

// Mini in-game HUD bar — 38px tall, tinted overlay, 3 zones.
// HUD time rounds to the second (no centiseconds) per design spec.
function HUD({ worldIndex, levelIndex, elapsedMs, coinsCollected, coinsTotal, deaths }) {
  const wd = WORLDS[worldIndex];
  const lv = wd.ls[levelIndex];
  const seconds = Math.floor(elapsedMs / 1000);
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  const time = (m ? m + ':' : '') + (m ? String(s).padStart(2,'0') : s);

  return (
    <div className="pw-hud" style={{ '--accent-rail': hexToRgba(wd.c, .55) }}>
      <div className="pw-hud-l" style={{ color: tintLight(wd.c) }}>
        <Emblem kind={EMBLEM_KIND[worldIndex]} size={14} />
        <span style={{ marginLeft: 6 }}>{wd.n}</span>
        <span className="pw-hud-crumb"> › {lv.n}</span>
      </div>
      <div className="pw-hud-c">
        <span className="pw-hud-time">{time}</span>
        <span className="pw-hud-coin" />
        <span className="pw-hud-cnt">{coinsCollected}/{coinsTotal}</span>
      </div>
      <div className="pw-hud-r">
        <span>☠ {deaths}</span>
        <span className="pw-hud-esc">ESC = menu</span>
      </div>
    </div>
  );
}

// helpers — convert hex like "#2196F3" into rgba(...) with the given alpha,
// and brighten an accent for the HUD label color
function hexToRgba(hex, a) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0,2), 16),
        g = parseInt(h.slice(2,4), 16),
        b = parseInt(h.slice(4,6), 16);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
function tintLight(hex) {
  // mix toward white 50%
  const h = hex.replace('#', '');
  const r = Math.round((parseInt(h.slice(0,2),16) + 255) / 2);
  const g = Math.round((parseInt(h.slice(2,4),16) + 255) / 2);
  const b = Math.round((parseInt(h.slice(4,6),16) + 255) / 2);
  return `rgb(${r},${g},${b})`;
}

window.HUD = HUD;
