/* global React, EMBLEM_KIND, Emblem */

// MainMenu — purple twilight sky · drifting nebulae + crescent moon · pixel clouds ·
// floating-island row (one per world) · italic two-tone title with split divider ·
// prompt button beneath.  Recreates src/game/scenes/MainMenu.js verbatim.

function MainMenu({ onStart }) {
  // 60 deterministic stars (same constants as the game)
  const stars = [];
  for (let i = 0; i < 60; i++) {
    const big = i % 5 === 0;
    const tw  = i % 3 === 0;
    stars.push(
      <i key={i}
         className={(big ? 'big ' : '') + (tw ? 'tw' : '')}
         style={{
           left: ((i*97+3) % 800) + 'px',
           top:  ((i*61+5) % 260) + 'px',
           animationDelay: ((i*0.17) % 2.4).toFixed(2) + 's',
         }} />
    );
  }

  // 5 floating islands — one per world.
  // Positions match Game's main-menu layout (cx, cy in 800×450 space).
  // Each island = grass top + sheen + edge highlight + dirt body + tapering roots.
  const ISLANDS = [
    // wi, cx, cy, w, h, grass, dirt, accent, emblem
    { wi: 0, cx:  88, cy: 286, w: 122, h: 22, grass: '#1875c8', dirt: '#0d1a2e', accent: '#2196F3' },
    { wi: 1, cx: 248, cy: 265, w: 108, h: 20, grass: '#8844aa', dirt: '#100828', accent: '#CE93D8' },
    { wi: 2, cx: 400, cy: 279, w: 120, h: 22, grass: '#b87818', dirt: '#1e1408', accent: '#FFCC80' },
    { wi: 3, cx: 554, cy: 263, w: 108, h: 20, grass: '#189898', dirt: '#081c20', accent: '#80DEEA' },
    { wi: 4, cx: 708, cy: 273, w: 114, h: 20, grass: '#c42800', dirt: '#1c0808', accent: '#FF7043' },
  ];

  function Island({ wi, cx, cy, w, h, grass, dirt, accent, idx }) {
    const half = w / 2;
    return (
      <div className="pw-island"
           style={{
             left: (cx - half) + 'px',
             top:  (cy - 30) + 'px',           // emblem hovers 22 px above grass top
             width: w + 'px',
             animationDelay: (-idx * 0.8) + 's',
           }}>
        {/* Emblem floating above the grass */}
        <div className="pw-island-emblem">
          <Emblem kind={EMBLEM_KIND[wi]} size={34} />
        </div>
        <svg width={w} height={h + 22} viewBox={`0 0 ${w} ${h + 22}`}
             shapeRendering="crispEdges" style={{ display: 'block' }}>
          {/* Tufts */}
          {Array.from({ length: Math.floor((w - 10) / 9) }, (_, i) => (
            <rect key={'t' + i} x={5 + i * 9} y="0" width="2" height="3" fill={grass}/>
          ))}
          {/* Top highlight */}
          <rect x="0" y="3" width={w} height="1" fill="#fff" opacity=".18"/>
          {/* Accent sheen */}
          <rect x="0" y="3" width={w} height="2" fill={accent} opacity=".35"/>
          {/* Grass top */}
          <rect x="0" y="3" width={w} height="5" fill={grass}/>
          {/* Dirt body */}
          <rect x="0" y="8" width={w} height={h - 4} fill={dirt}/>
          {/* Underside shadow */}
          <rect x="0" y={h - 4 + 4} width={w} height="4" fill="#000" opacity=".30"/>
          {/* Hanging roots */}
          <rect x="10"      y={h + 4} width={w - 20} height="6" fill={dirt} opacity=".90"/>
          <rect x="20"      y={h + 10} width={w - 40} height="5" fill={dirt} opacity=".80"/>
          <rect x="30"      y={h + 15} width={w - 60} height="4" fill={dirt} opacity=".70"/>
        </svg>
      </div>
    );
  }

  return (
    <div className="pw-scene pw-menu" onClick={onStart}>
      {/* Twilight sky base */}
      <div className="pw-menu-sky" />

      {/* Drifting nebula wisps */}
      <div className="pw-neb pw-neb-1" />
      <div className="pw-neb pw-neb-2" />
      <div className="pw-neb pw-neb-3" />

      {/* Stars */}
      <div className="pw-stars">{stars}</div>

      {/* Pixel clouds */}
      <div className="pw-cloud pw-cloud-1"><i/><i/><i/></div>
      <div className="pw-cloud pw-cloud-2"><i/><i/><i/></div>
      <div className="pw-cloud pw-cloud-3"><i/><i/><i/></div>

      {/* Crescent moon */}
      <div className="pw-moon" />

      {/* Floating islands */}
      <div className="pw-islands">
        {ISLANDS.map((d, idx) => <Island key={d.wi} {...d} idx={idx} />)}
      </div>

      {/* Ground strip */}
      <div className="pw-menu-ground" />

      {/* World-emblem strip on the ground */}
      <div className="pw-menu-emblems">
        {[0,1,2,3,4].map((wi) => {
          const accent = ISLANDS[wi].accent;
          const name = ['PIRATE','NINJA','WILD','OCEAN','FIRE'][wi];
          return (
            <div key={wi} className="pw-menu-em-tile" style={{ '--accent': accent }}>
              <div className="pw-menu-em-tile-bg"><i/><i/><i/></div>
              <div className="pw-menu-em-tile-em">
                <Emblem kind={EMBLEM_KIND[wi]} size={28} />
              </div>
              <div className="pw-menu-em-tile-lbl">{name}</div>
            </div>
          );
        })}
      </div>

      {/* TITLE PANEL */}
      <div className="pw-menu-panel" />

      {/* Italic two-tone title */}
      <div className="pw-menu-title">
        <span className="l">PARKOUR</span>
        <span className="r">WORLDS</span>
      </div>

      {/* Divider */}
      <div className="pw-menu-divider"><i/><i/></div>

      {/* Subtitle */}
      <div className="pw-menu-sub">5 worlds &nbsp;·&nbsp; 20 levels &nbsp;·&nbsp; beat the clock</div>

      {/* Prompt button */}
      <div className="pw-menu-prompt">PRESS&nbsp;&nbsp;SPACE&nbsp;&nbsp;OR&nbsp;&nbsp;CLICK&nbsp;&nbsp;TO&nbsp;&nbsp;START</div>
    </div>
  );
}

window.MainMenu = MainMenu;
