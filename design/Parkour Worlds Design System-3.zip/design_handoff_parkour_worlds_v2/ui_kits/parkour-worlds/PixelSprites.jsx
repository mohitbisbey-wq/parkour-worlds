/* global React */

// 18×26 player sprite — 5-rect stack from the game
function PlayerSprite({ scale = 1 }) {
  return (
    <div className="px-player" style={{ transform: `scale(${scale})`, transformOrigin: 'bottom center' }}>
      <div className="ph2" /><div className="ph1" /><div className="band" />
      <div className="face" /><div className="eye" />
      <div className="coat" /><div className="belt" /><div className="buckle" />
      <div className="shoeL" /><div className="shoeR" />
    </div>
  );
}

// 14×14 coin — bobs via CSS
function CoinSprite({ scale = 1 }) {
  return <div className="px-coin" style={{ transform: `scale(${scale})` }} />;
}

// 36×26 chest at level end
function ChestSprite({ scale = 1 }) {
  return (
    <div className="px-chest" style={{ transform: `scale(${scale})`, transformOrigin: 'bottom center' }}>
      <div className="lid"/><div className="bandT"/>
      <div className="body"/><div className="bandB"/>
      <div className="lockT"/><div className="lockB"/>
    </div>
  );
}

// Checkpoint flag — 22×42, red (untouched) or green (triggered)
function FlagSprite({ triggered = false, scale = 1 }) {
  const stripes = [
    { top: 0,  w: 13, cls: 'hi' },
    { top: 1,  w: 13, cls: 'hi' },
    { top: 2,  w: 13, cls: '' },
    { top: 3,  w: 12, cls: '' },
    { top: 4,  w: 11, cls: '' },
    { top: 5,  w: 10, cls: '' },
    { top: 6,  w:  9, cls: '' },
    { top: 7,  w:  7, cls: 'lo' },
    { top: 8,  w:  5, cls: 'lo' },
    { top: 9,  w:  3, cls: 'lo' },
    { top: 10, w:  1, cls: 'lo' },
  ];
  return (
    <div className={'px-flag ' + (triggered ? 'green' : 'red')}
         style={{ transform: `scale(${scale})`, transformOrigin: 'bottom center' }}>
      {triggered && (
        <>
          <div className="spark s1"/><div className="spark s2"/><div className="spark s3"/>
        </>
      )}
      <div className="knob1"/><div className="knob2"/><div className="knob3"/>
      <div className="poleL"/><div className="poleR"/>
      <div className="base1"/><div className="base2"/><div className="base3"/>
      <div className="pen">
        <div className="poleShadow"/>
        {stripes.map((s, i) => (
          <div key={i} className={'stripe ' + s.cls}
               style={{ top: s.top, width: s.w + 'px' }} />
        ))}
      </div>
      <div className="tassel"/><div className="tasselTip"/>
    </div>
  );
}

// 12×18 enemy — body color cycles per world
const ENEMY_BODY = ['#8B0000', '#1a003a', '#6b3a1f', '#005f6b', '#8B2500'];
const ENEMY_EYE  = ['#ff4444', '#dd88ff', '#ffbb44', '#44ffee', '#ff6600'];
function EnemySprite({ worldIndex = 0, scale = 1 }) {
  return (
    <div className="px-enemy" style={{ transform: `scale(${scale})`, transformOrigin: 'bottom center' }}>
      <div className="hat2"/><div className="hat1"/>
      <div className="body" style={{ background: ENEMY_BODY[worldIndex] }}/>
      <div className="head"/>
      <div className="eye"  style={{ background: ENEMY_EYE[worldIndex],
                                     boxShadow: '0 0 4px ' + ENEMY_EYE[worldIndex] }}/>
      <div className="footL"/><div className="footR"/>
    </div>
  );
}

Object.assign(window, { PlayerSprite, CoinSprite, ChestSprite, FlagSprite, EnemySprite });
