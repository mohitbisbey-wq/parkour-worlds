/* global React */
const { useState } = React;

function Starfield({ density = 60, twinkle = false }) {
  const stars = [];
  for (let i = 0; i < density; i++) {
    stars.push(
      <i key={`s${i}`}
         style={{
           left: ((i*97+3) % 800) + 'px',
           top:  ((i*61+5) % 450) + 'px',
           opacity: 0.32,
         }} />
    );
  }
  for (let i = 0; i < density / 4; i++) {
    stars.push(
      <i key={`b${i}`} className="big"
         style={{
           left: ((i*173+15) % 800) + 'px',
           top:  ((i*83+20) % 450) + 'px',
           opacity: twinkle ? undefined : 0.7,
         }} />
    );
  }
  return <div className="pw-stars">{stars}</div>;
}

window.Starfield = Starfield;
