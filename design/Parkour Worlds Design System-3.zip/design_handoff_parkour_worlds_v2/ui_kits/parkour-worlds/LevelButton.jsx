/* global React, fmt */

function LevelButton({ levelName, idx, accent, status, time, onClick }) {
  // status: 'cleared' | 'play' | 'locked'
  const locked = status === 'locked';
  return (
    <div className={'pw-lvbtn ' + (locked ? 'locked' : '')}
         style={{ '--accent': accent }}
         onClick={locked ? undefined : onClick}
         title={levelName}>
      <div className="ln">{levelName}</div>
      {status === 'cleared'
        ? <div className="st gold">★ {fmt(time)}</div>
        : status === 'play'
        ? <div className="st">play</div>
        : <div className="st locked">🔒 locked</div>}
    </div>
  );
}

window.LevelButton = LevelButton;
