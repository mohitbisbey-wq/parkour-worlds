// Worlds dataset for the UI kit — copied 1:1 from src/game/data/worlds.js
// (Level platforms / coins / checkpoints / goals omitted — UI kit does not
// render gameplay. Only the world + level metadata used by the chrome.)
const WORLDS = [
  { n: 'Pirate Seas',      e: '⚓',  c: '#2196F3', bg: ['#1a6bb5', '#0d3d6e'], bot: '#0a2a5a',
    ls: [{ n: 'Harbor Docks' }, { n: 'Ship Masts' }, { n: 'Jungle Ruins' }, { n: 'Kraken Depths' }] },
  { n: 'Ninja Dojo',       e: '🥷',  c: '#CE93D8', bg: ['#12082b', '#070418'], bot: '#040210',
    ls: [{ n: 'Rooftop Rush' }, { n: 'Bamboo Climb' }, { n: 'Pagoda Peak' }, { n: 'Shadow Summit' }] },
  { n: 'Wild West',        e: '🤠',  c: '#FFCC80', bg: ['#c04a1a', '#7a2c08'], bot: '#4a1800',
    ls: [{ n: 'Dusty Trail' }, { n: 'Canyon Run' }, { n: 'Gold Mine' }, { n: "Dead Man's Pass" }] },
  { n: 'Deep Ocean',       e: '🐚',  c: '#80DEEA', bg: ['#011640', '#010820'], bot: '#010412',
    ls: [{ n: 'Coral Garden' }, { n: 'Kelp Forest' }, { n: 'The Abyss' }, { n: 'The Trench' }] },
  { n: 'Fire & Brimstone', e: '🔥',  c: '#FF7043', bg: ['#3c0000', '#1a0000'], bot: '#ff3d00',
    ls: [{ n: 'Ember Fields' }, { n: 'Volcano Climb' }, { n: 'The Inferno' }, { n: 'The Core' }] },
  { n: 'Practice',         e: '🎯',  c: '#aaaaaa', bg: ['#2a2a2a', '#1a1a1a'], bot: '#111111',
    ls: [{ n: 'Test Zone' }] },
];

// Demo save data — first world fully cleared, second world 2/4 cleared,
// everything beyond locked. Best times are arbitrary but realistic.
const DEMO_DONE = [
  true, true, true, true,     // Pirate Seas (4/4)
  true, true, false, false,   // Ninja Dojo  (2/4)
  false, false, false, false, // Wild West   (locked)
  false, false, false, false, // Deep Ocean  (locked)
  false, false, false, false, // Fire        (locked)
];
const DEMO_BESTS = {
  0:  [18420, 22070, 24930],
  1:  [27110, 31280],
  2:  [29840],
  3:  [42050, 47200, 51080],
  4:  [16320, 19100, 21750],
  5:  [33620, 38990],
};

// fmt(ms) → "m:ss.cc" — matches the in-engine helper exactly.
function fmt(ms) {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const cs = Math.floor((ms % 1000) / 10);
  return `${m ? m + ':' : ''}${String(s).padStart(m ? 2 : 1, '0')}.${String(cs).padStart(2, '0')}`;
}

// Unlock predicates — same logic as src/game/utils/save.js
function wUnlk(wi, done) {
  if (wi === 0 || wi === 5) return true;
  return [0,1,2,3].every(li => done[(wi - 1) * 4 + li]);
}
function lUnlk(wi, li, done) {
  return wUnlk(wi, done) && (li === 0 || done[wi * 4 + li - 1]);
}

Object.assign(window, { WORLDS, DEMO_DONE, DEMO_BESTS, fmt, wUnlk, lUnlk });
