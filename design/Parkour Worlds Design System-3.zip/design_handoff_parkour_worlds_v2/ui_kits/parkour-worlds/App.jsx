/* global React, MainMenu, WorldSelect, WorldStage, HUD, LevelCompleteModal, WORLDS, DEMO_BESTS */

const { useState, useEffect, useRef } = React;

// Sample run times — used when the user "finishes" a fake level
const SAMPLE_RUN_MS = [
  [18420, 24070, 29840, 42050],
  [27110, 31280, 33620, 38990],
  [21340, 27520, 31080, 34910],
  [22810, 28640, 32970, 41200],
  [16320, 19100, 21750, 28430],
  [33620],
];

function App() {
  const [scene, setScene] = useState('menu'); // menu | worldselect | play | complete
  const [wi, setWi] = useState(0);
  const [li, setLi] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [coins, setCoins] = useState(0);
  const [deaths, setDeaths] = useState(0);
  const timerRef = useRef(null);

  function start(wi, li) {
    setWi(wi); setLi(li);
    setElapsed(0); setCoins(0); setDeaths(0);
    setScene('play');
  }

  // Faux gameplay timer — ticks while "play"-ing
  useEffect(() => {
    if (scene !== 'play') return;
    const t0 = Date.now();
    timerRef.current = setInterval(() => {
      setElapsed(Date.now() - t0);
      // every 4s, random coin pickup, every ~8s a death — to make the HUD feel alive
      if (Math.random() < 0.04) setCoins(c => Math.min(c + 1, 10));
      if (Math.random() < 0.008) setDeaths(d => d + 1);
    }, 100);
    return () => clearInterval(timerRef.current);
  }, [scene]);

  // ESC = back; SPACE on play = "finish" the level
  useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'Escape') {
        if (scene === 'play' || scene === 'complete') setScene('worldselect');
        else if (scene === 'worldselect') setScene('menu');
      }
      if (e.code === 'Space') {
        if (scene === 'menu') setScene('worldselect');
        else if (scene === 'play') setScene('complete');
        else if (scene === 'complete') {
          // next level
          if (li < WORLDS[wi].ls.length - 1) start(wi, li + 1);
          else setScene('worldselect');
        }
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [scene, wi, li]);

  const sample = SAMPLE_RUN_MS[wi]?.[li] ?? 30000;
  const runMs = scene === 'complete' ? sample : elapsed;

  return (
    <div className="pw-frame">
      {scene === 'menu'        && <MainMenu onStart={() => setScene('worldselect')} />}
      {scene === 'worldselect' && <WorldSelect onPlayLevel={start} onBack={() => setScene('menu')} />}

      {(scene === 'play' || scene === 'complete') && (
        <>
          <WorldStage worldIndex={wi} />
          <HUD
            worldIndex={wi} levelIndex={li}
            elapsedMs={runMs}
            coinsCollected={coins} coinsTotal={10}
            deaths={deaths}
          />
          {scene === 'complete' && (
            <LevelCompleteModal
              runMs={sample}
              bestTimes={[sample, sample + 2650, sample + 6510]}
              runRank={0}
              deaths={deaths}
              coinsCollected={coins} coinsTotal={10}
              onNext={() => {
                if (li < WORLDS[wi].ls.length - 1) start(wi, li + 1);
                else setScene('worldselect');
              }}
              onBack={() => setScene('worldselect')}
            />
          )}
        </>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
