# Parkour Worlds — UI Kit

Hi-fi React/JSX recreations of the four core screens of Parkour Worlds. **This is a UI kit, not a playable game** — you can click from Main Menu → World Select → "playing" (HUD only) → Level Complete modal, but there is no Phaser physics or canvas rendering. The point is to pixel-match the game's chrome at the React/DOM level so designers can pull individual components into new mockups.

## Open

Open `index.html` in a browser. The whole demo is a self-contained 800×450 viewport that loosely mirrors the actual canvas size.

## Files

| File | What |
|---|---|
| `index.html` | Bootstraps React, Babel, all components below. Single entry. |
| `data.js` | The world/level dataset, copied 1:1 from `src/game/data/worlds.js`. |
| `App.jsx` | Top-level scene switcher (`menu` → `worldselect` → `play` → `complete`). |
| `MainMenu.jsx` | Title screen with starfield, blinking prompt. |
| `WorldSelect.jsx` | 5-column world grid + practice pill. |
| `WorldCard.jsx` | One column of the grid. Renders unlocked & locked states. |
| `LevelButton.jsx` | A row inside a world card. 4 states. |
| `HUD.jsx` | Top bar shown during "play" — world breadcrumb, clock, coins, deaths. |
| `LevelCompleteModal.jsx` | The completion overlay with best-times table. |
| `PixelSprites.jsx` | Player / coin / chest / flag / enemy as CSS pixel art (`absolute` divs). |
| `WorldStage.jsx` | A faux gameplay backdrop — sky gradient, floor, decals, sprites — non-interactive. |
| `Starfield.jsx` | Reusable deterministic star background. |
| `kit.css` | Component-level CSS that uses the tokens from the parent `colors_and_type.css`. |

## Component philosophy

- **No Phaser, no canvas.** Every game-y visual is built from `div`s with `position: absolute` and the token color palette. Sprites use CSS pixel art (small colored rectangles, like the original `fillRect` calls).
- **No icon library.** Emoji and Unicode glyphs only — same rule as the source.
- **Tokens > magic numbers.** Pull everything from `--pw-*` in `../../colors_and_type.css` so designers can re-skin the whole thing by editing one file.
- **Interactive but lossy.** Hover and click work. Wall-jump physics, level rendering, save persistence — all out of scope.

## Out of scope (intentionally)

- Phaser scenes / arcade physics
- Actual level rendering (the platforms, the player movement)
- Save data persistence to `window.storage`
- Sound effects
- The Game Over scene (`src/game/scenes/GameOver.js` is an older Phaser template artifact, not part of the shipping flow)
