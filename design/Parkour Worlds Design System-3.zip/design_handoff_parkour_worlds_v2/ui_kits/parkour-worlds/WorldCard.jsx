/* global React, Emblem, EMBLEM_KIND, LevelButton, WORLDS, DEMO_DONE, DEMO_BESTS, wUnlk, lUnlk */

function WorldCard({ wi, onPlayLevel }) {
  const wd = WORLDS[wi];
  const unlk = wUnlk(wi, DEMO_DONE);
  const prevName = WORLDS[wi - 1]?.n;

  if (!unlk) {
    return (
      <div className="pw-wcard locked" style={{ '--accent': wd.c }}>
        <div className="e" style={{ filter: 'grayscale(.6)', opacity: .5 }}>
          <Emblem kind={EMBLEM_KIND[wi]} size={26} />
        </div>
        <div className="name">{wd.n}</div>
        <div className="lock-glyph">🔒</div>
        <div className="lock-hint">clear {prevName}<br/>to unlock</div>
      </div>
    );
  }

  return (
    <div className="pw-wcard" style={{ '--accent': wd.c }}>
      <div className="e"><Emblem kind={EMBLEM_KIND[wi]} size={26} /></div>
      <div className="name">{wd.n}</div>
      <div className="stars">
        {[0,1,2,3].map(i => {
          const cleared = DEMO_DONE[wi*4 + i];
          return <span key={i} className={'s ' + (cleared ? 'on' : 'off')}>★</span>;
        })}
      </div>
      <div className="levels">
        {wd.ls.map((lv, li) => {
          const idx = wi*4 + li;
          const cleared = DEMO_DONE[idx];
          const canPlay = lUnlk(wi, li, DEMO_DONE);
          const status = cleared ? 'cleared' : canPlay ? 'play' : 'locked';
          const best = DEMO_BESTS[idx]?.[0];
          return (
            <LevelButton key={li}
              levelName={lv.n} idx={li} accent={wd.c}
              status={status} time={best}
              onClick={() => onPlayLevel(wi, li)} />
          );
        })}
      </div>
    </div>
  );
}

window.WorldCard = WorldCard;
