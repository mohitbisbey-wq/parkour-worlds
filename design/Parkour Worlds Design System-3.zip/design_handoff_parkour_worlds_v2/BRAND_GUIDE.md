# Parkour Worlds — Design System

A design language for **Parkour Worlds**, a 5-world pixel-art platformer built on Phaser. The look is **arcade-cab cosmic**: pitch-black void chrome, monospaced bold type, electric-purple brand color, gold reserved for earned rewards, and a per-world atmospheric palette that swaps on every level.

> **Source repo:** [`mohitbisbey-wq/Platformer-v1`](https://github.com/mohitbisbey-wq/Platformer-v1) (private, default branch `main`). Built on the [`phaserjs/template-webpack`](https://github.com/phaserjs/template-webpack) starter — `public/assets/logo.png`, `public/favicon.png`, and `screenshot.png` are template defaults (Phaser branding), not Parkour Worlds assets, and were intentionally NOT brought into this system.

---

## Product

A single game, two surfaces:

| Surface | Location in repo | What it is |
|---|---|---|
| **Game (Phaser/webpack build)** | `src/game/scenes/*.js` + `src/game/data/worlds.js` | The shipping product. Scenes: `Boot → Preloader → MainMenu → WorldSelect → Game`. |
| **Per-world chiptune** | `src/game/utils/music.js` | Procedural Web Audio. 6 tracks (5 worlds + menu + practice). No `.mp3` files in the repo. |

**5 unlockable worlds + a Practice room. Each world has 4 timed levels. 20 levels total.** Goal: beat the chest, beat the clock, top-3 your own runs.

| # | World | Emblem | Accent | Sky | Tile body |
|---|---|---|---|---|---|
| 1 | Pirate Seas | ⚓ anchor | `#2196F3` | `#1a6bb5 → #0d3d6e` | `#1A3448` weathered navy wood |
| 2 | Ninja Dojo | 🥷 shuriken | `#CE93D8` | `#12082b → #070418` | `#18102C` polished dark stone |
| 3 | Wild West | 🌵 cactus | `#FFCC80` | `#c04a1a → #7a2c08` | `#5A3418` sandstone / adobe |
| 4 | Deep Ocean | 🐚 shell | `#80DEEA` | `#011640 → #010820` | `#082030` coral stone |
| 5 | Fire & Brimstone | 🔥 flame | `#FF7043` | `#3c0000 → #1a0000` | `#140808` obsidian + lava veins |
| — | Practice | 🎯 target | `#aaaaaa` | `#2a2a2a → #1a1a1a` | `#2A2A2A` neutral grey |

---

## Index

| Path | What |
|---|---|
| `README.md` | This file. Brand context, content + visual rules, iconography. |
| `SKILL.md` | Cross-compatible Agent Skill manifest (`parkour-worlds-design`). |
| `colors_and_type.css` | All design tokens — colors, type scale, spacing, radii, motion. |
| `assets/ICONOGRAPHY.md` | Catalog of world emblems + semantic glyphs. |
| `preview/` | Standalone HTML cards rendered in the Design System tab. Each demonstrates one token, palette, type style, or component. |
| `snippets/` | Paste-ready HTML fragments — title screen, emblem SVGs, sprite CSS. |
| `ui_kits/parkour-worlds/` | Hi-fi React/JSX recreation of the four core scenes (Main Menu w/ floating islands, World Select, in-game HUD, Level Complete modal). `index.html` boots an interactive demo. |
| `src/`, `public/` | Game source code imported from the GitHub repo for reference. Treat as read-only. |

---

## CONTENT FUNDAMENTALS

The whole game speaks in **arcade-cab tone**: short, declarative, imperative, with a dry sense of humor in micro-copy. No marketing voice, no sentences longer than one breath.

**Casing.**
- **UPPERCASE** for chrome and signal: `PARKOUR WORLDS`, `CHOOSE YOUR WORLD`, `PRESS SPACE OR CLICK TO START`, `PLAY`, `LOCKED`, `CLEARED`.
- **Title Case** for nouns the player owns — level names, world names: `Harbor Docks`, `Shadow Summit`, `Dead Man's Pass`.
- **lower case** for soft asides and tertiary hints: `cleared`, `not a top 3 time`, `play`, `to unlock`, `practice`.
- Mixed case allowed on the completion modal headline: `Level Complete!` — the single concession to non-arcade warmth.

**Voice.**
- Second-person, sparing. "Choose your world." "You conquered all 5 worlds!"
- Never "we", never "our". The game does not have a personality — only the player does.
- Sentence fragments preferred. Punctuation only where it changes meaning.

**Separators.**
- Middle dot ` · ` between siblings: `5 worlds  ·  20 levels  ·  beat the clock`.
- Triangle ` › ` for breadcrumb pairs in the HUD: `⚓ Pirate Seas › Harbor Docks`.
- Em-dash `—` for callouts: `🎯 Test Zone — practice`.

**Numbers + counters.**
- Times are `m:ss.cc` (`fmt()` in code). Always tabular. `0:18.42`, `1:47.09`. In the HUD only the seconds portion shows live; the centiseconds appear in the complete modal.
- Coins are `got / total`: `7/10`. Always with the slash, never "of".
- Deaths are prefixed with the skull glyph `☠`: `☠ 3`. Singular/plural collapsed: `☠ 1 death`, `☠ 4 deaths`.

**Symbols used semantically.**
- `★` — completed level marker AND personal-best row marker. Gold = hit, dim white = empty.
- `🔒` — locked content. Always paired with `LOCKED` or "to unlock".
- `◀` — your-current-run cursor next to a best-time row.
- `☠` — death counter.
- A small **dash diamond** (drawn 8×8 in the HUD) — bright cyan when ready, dim slate when spent.

**Emoji as branding.** Each world has a single emoji that is **the** brand mark for that world, used at small sizes. The full-bleed emblem treatment is **pixel-art**, not emoji (see ICONOGRAPHY).

**No emoji as decoration.** Emoji never used to spice up copy.

**Examples — direct lifts from the code.**

```
PARKOUR
WORLDS
5 worlds  ·  20 levels  ·  beat the clock
PRESS SPACE OR CLICK TO START

CHOOSE YOUR WORLD
WASD / Arrows  move  ·  Space  jump  ·  Push wall + jump  =  wall jump
Shift / Z = dash  ·  M = mute
ESC = back

⚓ Pirate Seas › Harbor Docks      0:18      ◆ 7/10      ☠ 3

Level Complete!
0:18.42
★ New Best! #1
BEST TIMES
#1   0:18.42  ◀
#2   0:21.07
#3   0:24.93
☠ 3 deaths    7/10 coins
SPACE → next level
ESC → world select

🎯  Test Zone  —  practice
🔒 LOCKED
clear ⚓
to unlock
```

**Things this voice never says:** "Welcome!", "Get ready!", "Awesome!", "Are you sure?", "Oops". Never explains itself. Never apologizes.

---

## VISUAL FOUNDATIONS

The whole product is rendered to an **800×450** canvas with `pixelArt: true`. Every visual rule below stems from "this is a sub-1MB pixel-art platformer running in a black browser frame."

**Backgrounds.**
- **Main Menu** is its own scene with its own palette — purple twilight gradient (`#0c0420 → #181660`), drifting nebula wisps, a crescent moon, and **5 floating world-islands** in a horizontal row, each capped with grass + dirt + hanging roots and a pixel-art emblem hovering above. The HUD void color `#06060f` is reserved for World Select and other chrome.
- Inside levels: a single vertical 2-stop gradient per world (sky-top → sky-bot) with a darker floor strip glued to the bottom 28px and **three layered parallax decals** drawn in JS per world:
  - Pirate Seas: distant islands → lighthouse → ship silhouettes → pixel sun + clouds + horizon glow.
  - Ninja Dojo: tiered pagodas → bamboo stalks → twinkling stars + crescent moon → aurora bands → swaying lanterns.
  - Wild West: mesa buttes → cacti row → heat-ring sun → tumbleweeds → dust haze.
  - Deep Ocean: fan coral → jellyfish silhouettes → caustic light streaks → bubbles + kelp + biolume sparkle floor.
  - Fire & Brimstone: volcano silhouettes → lava-river channels → ember sparks → lava pool glow → rising smoke plumes.
- Body of the OS/embed shell is always `#000`. The canvas itself has an 8px rounded corner — the only place rounded corners appear in the actual game.

**Type.**
- One family: generic `monospace` (substituted with `JetBrains Mono` on the web). Bold is the default.
- The Main Menu title uses **bold italic monospace** with a colored two-tone split: `PARKOUR` in gold, `WORLDS` in brand purple, anchored on a shared vertical center.
- Scale is small and discrete: 56 / 48 / 24 / 22 / 15 / 14 / 13 / 12 / 11 / 10 / 9 / 8.
- Uppercase + tracking on labels, Title Case on proper nouns, lower-case on whispers.
- No fancy text effects — no gradients-on-text, no glow filters. Color and italics signal hierarchy.

**Color.**
- **Three signal colors**: brand purple `#b888ff` (chrome — title, prompts, accent ring on Menu panel), reward gold `#FFD700` (coins, stars, personal bests, "PARKOUR" half of title), and the per-world accent.
- **World accent** is one hue per world, used for HUD breadcrumb tint, world-card stroke + top rail, platform tile edges, dash trail color, coin tint, and a thousand small details.
- **Atmospheric** (sky/floor pairs) per-world only; never on chrome.
- Translucency is the primary device for layers. Whites at 4/7/8/12% for surfaces; whites at 15/20/25/35/45% for ink hierarchy.

**Spacing.**
- Implicit 2-px base unit (the in-engine padding constants are 2, 5, 6, 8, 12, 13). 4-px grid is the clean web translation.
- World cards: 136×316 with 13px gap.
- HUD bar is exactly 38px tall, 9px horizontal pad to the canvas edge.
- Floating islands: 108–122 px wide, 20–22 px thick, ~13–14 px vertical jitter between adjacent islands for rhythm.

**Borders + cards.**
- Cards: 1.5px stroke. Inactive cards: 1px stroke at 8–15% white.
- Active cards: stroke is the world accent at full alpha + a 4-px top rail in the same accent color.
- The Main Menu title panel: 464×152 dark interior (`#080418` @ 76%) with a 1px purple stroke at 22% and a 2px purple top rail.
- Radii are restrained: card 8, level button 5, complete modal 10. Gameplay platforms have zero radius.
- No drop shadows. Elevation is communicated with outline glow halos and nothing else.

**Platforms (per-world tile system).**
- Every platform is rendered as a body fill + 8×8 seam grid + corner dots ("X-pattern") + a bright 2px top edge + 1px sub-highlight + dark bottom shadow + world-specific surface decoration above the top edge.
- Surface decoration per world:
  - Pirate: scattered foam bumps + white spec dots (sea-spray).
  - Ninja: short purple energy wisps standing up off the tile.
  - West: sand grain noise + pebbles.
  - Ocean: coral / seaweed tufts (~6 px tall).
  - Fire: cracked lava crust + ember sparks.
- Each world owns 7 tile colors: `coat` (player coat tint), `body`, `edgeHi`, `edgeSub`, `seam`, `tileInner`, `surf`. See `colors_and_type.css` `--pw-tile-*` tokens.

**Hover + press states.**
- Buttons: default fill = white at 8%; on hover, fill = world accent at 20% and stroke 60% → 100% alpha at 1.5px. On press, 30% fill flash.
- Player, chest, triggered checkpoint get pulsing glow halos, not shadows.

**Transparency + blur.**
- The completion modal is `rgba(0,0,0,0.75)` over the still-running level — **no backdrop-filter blur** in the original. Do not add blur in design-system recreations either.

**Animation + motion.**
- Five primitives:
  1. Linear blink — start prompt + complete-modal "next level" CTA fade 1→0 over 500–650ms yoyo.
  2. Sin-pulse glow — `0.1 + sin(t*6)*0.2` halo intensities (chest, checkpoint-on, end-of-level).
  3. Bobbing sprites — coins bob ±3px on `sin(t*2.5 + x*0.07)`.
  4. **Dash trail** — last 7 player-frame positions drawn behind the player as fading rectangles in the world accent at increasing alpha (0 → 0.45).
  5. Floating-island lift — gentle ±4 px vertical breathing, 4 s ease-in-out, staggered per island.
- Easing for UI: `Sine.easeInOut` on Phaser tweens, otherwise step-discrete.
- No fades between scenes. Scene swap is instant.

**Imagery vibe.**
- Cold or hot, never neutral. Worlds 1, 2, 4 are deep cool blues/purples; 3 and 5 are saturated hot oranges/reds. Practice is the only "warm grey" zone.
- No film grain. No noise. No photography. Everything is a few thousand pixels of solid color rectangles.

**Layout rules.**
- Everything that's not gameplay lives in an 800×450 viewport with center-anchored text.
- HUD: top-aligned, 38px tall, 3 zones (left = `emoji + world › level`, center = `dash diamond | timer | coin dot + count`, right = `☠ deaths` and `ESC = menu`). A small mute speaker glyph anchors the lower-right.
- Modals: 392×292, centered, gold halo `rgba(255,215,0,.30)` stroke.
- World select grid: 5 columns × 1 row, centered, 13px gap, plus a single Practice button below.

**Fixed elements.**
- HUD bar (always present in `play` and `complete` phases).
- ESC hint in bottom-right corner of menus.
- Canvas-level prompt for input when game is idle.

**Hardcoded "don't break" rules.**
- **Coins are pixel-art diamonds**, not circles. The shape is two stacked rects (`8×12` over a wider `12×6` band) with a 3×3 specular dot top-left. Tint = world accent (`COIN_COLORS[wi]` in `Game.js`).
- **Checkpoint flag** is a single 1×40 grey pole with a triangular pennant (red untriggered, green triggered, lit halo when triggered).
- **Player** is 18×26 body bounds, rendered as a stacked rect figure — shoes, pants, coat in the world's `coat` color, belt with gold buckle, face, eye, world-tinted hat brim + crown + highlight.
- **Chest** at end of every level: 36×26 wood box with a brass band and a gold lock.
- **Per-world enemies** — each world has its own enemy character (see ICONOGRAPHY + `preview/components-enemies.html`):
  - Pirate Seas: tricorn-hat captain with striped shirt, eye patch, cutlass.
  - Ninja Dojo: dark-mask ninja with glowing eye slit and shuriken in hand.
  - Wild West: bandana cowboy with revolver and wide brim hat.
  - Deep Ocean: walking red crab with bobbing eyestalks and alternating claws.
  - Fire & Brimstone: lava-cracked rock golem with a single pulsing lava eye.
  - Practice: generic boxy robot with a visor (default).

---

## ICONOGRAPHY

There is **no icon font**, **no SVG library**, **no PNG icon set** in the source. Iconography is built from three orthogonal sources:

### 1. Pixel-art world emblems
Each world has a hand-pixeled 16×16 emblem stored in `src/game/utils/emblems.js` as rectangle data. **These replace emoji at hero sizes** (Main Menu floating islands, World Select cards). Emoji are still used as a fallback in HUD breadcrumbs and tiny labels.

| World | Pixel emblem | Emoji fallback |
|---|---|---|
| Pirate Seas | anchor | ⚓ |
| Ninja Dojo | shuriken | 🥷 |
| Wild West | cactus | 🌵 / 🤠 |
| Deep Ocean | shell | 🐚 |
| Fire & Brimstone | flame | 🔥 |
| Practice | target | 🎯 |

See `preview/world-emblems.html` for the catalog and `snippets/emblems.html` for paste-ready inline SVGs.

### 2. Pictographic Unicode (semantic icons)
- `★` U+2605 — completion star + best-time star.
- `☠` U+2620 — death counter prefix.
- `◀` U+25C0 — your-current-run pointer.
- `🔒` U+1F512 — locked content marker.
- `›` U+203A — breadcrumb separator.
- `·` U+00B7 — middle dot separator.
- `—` U+2014 — callout em-dash.

### 3. Procedural pixel art (in-game entities)
Drawn directly to the canvas with `fillRect` / `arc` — never as image assets. Examples documented in `ui_kits/parkour-worlds/` and `preview/components-sprites.html`: player, diamond coin, chest, checkpoint, 6 enemy archetypes.

### Substitutions

For the HTML design-system demos we never add icon libraries the source doesn't use. Any iconography you see in the UI kit is either a pixel-art SVG emblem, system emoji, a Unicode glyph from the table above, or HTML/CSS pixel art drawn the same way the game draws it on canvas.

No Material Icons. No Lucide. No Heroicons. No FontAwesome. **The brand has rejected icon fonts implicitly by the simple fact of never adopting one.**

---

## MOTION & SOUND

The game ships a **procedural Web Audio chiptune track per world** plus a menu theme — no `.mp3`/`.ogg` files. All notes are generated from oscillators (sine / triangle / square / sawtooth) plus white noise for percussion. See `src/game/utils/music.js`. Each track is a look-ahead 16th-note sequencer with attack + decay envelopes.

| Scene | Key | BPM | Mood |
|---|---|---|---|
| Main Menu | D major | 100 | stately anthem — triangle melody + bass + sine pad chords |
| Pirate Seas | D major | 124 | shanty — sine bass + triangle melody + kick/snare/hi-hat |
| Ninja Dojo | D minor pentatonic | 72 | sparse — triangle pluck + sine drone + bell accents |
| Wild West | E major pentatonic | 92 | twangy — sawtooth lead + gallop clip-clop hi-hat |
| Deep Ocean | F minor | 50 | ambient — long sine pads + occasional bubble pop |
| Fire & Brimstone | E minor | 158 | driving — sawtooth bass + square lead + double kick |
| Practice | C major | 100 | 8-bit — square melody + bass + simple kick/snare |

`M` toggles mute. The current mute state shows as a small speaker glyph in the HUD bottom-right.

---

## FONTS

The shipping game uses the generic CSS keyword `monospace` for every text element. There are no `.ttf` / `.woff` files in `public/` or `src/`.

For the design system we substitute **JetBrains Mono** (Google Fonts, weights 400/700) — chosen for crisp legibility at 9–10px and a bold weight that holds at 56px. For the title display we additionally use **Press Start 2P** (Google Fonts) when we want a hard pixel-cab look on hero shots, but the in-engine title is just monospace bold italic — same family as the rest of the UI.

> ⚠️ **Substitution flag.** The original game ships no custom typeface. JetBrains Mono and Press Start 2P are *our* opinionated defaults for the design-system layer; the game itself will still render with system monospace.

Fallback chain: `'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, Consolas, 'Cascadia Code', 'Liberation Mono', monospace`.

---

## See also

- **`ui_kits/parkour-worlds/`** — interactive recreation of MainMenu (with floating islands + new title), WorldSelect, in-game HUD, and the Level Complete modal.
- **`preview/`** — small standalone cards for every token, palette, type style, component, and screen.
- **`SKILL.md`** — invocable as the `parkour-worlds-design` skill in Claude Code.
