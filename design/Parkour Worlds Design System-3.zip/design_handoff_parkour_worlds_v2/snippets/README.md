# Parkour Worlds — Paste-Ready Snippets

**For agents like Claude Code:** each file here is a self-contained block of HTML/JSX you can paste DIRECTLY into a project — no token imports, no relative paths, no dependencies beyond what's declared at the top of each snippet.

> **Never redraw these sprites from screenshots.** Copy the markup verbatim. Pixel art does not survive an LLM redraw — every rect, every coordinate, every color is intentional. If a snippet is missing, ask the user.

## Files

| Snippet | What |
|---|---|
| `title-screen.html` | Full title scene — Press Start 2P + 8-dir pixel outline + parallax mountains + beyblade player + moon + volcano + floating islands. **This is what fixes most title-screen mis-renders.** |
| `emblems.html` | All 6 world emblems as inline SVG. Drop a `<svg>` anywhere. |
| `sprites.html` | Player, coin, chest, checkpoint flag, enemy — as CSS-only DOM. |
| `world-card.html` | One world card with stars + 4 level buttons + locked state. |
| `level-button.html` | The 4 states of a level button. |
| `hud-bar.html` | The 32-px in-game HUD. |
| `level-complete-modal.html` | The completion modal, world-tinted. |

## Rules for agents

1. **Read the file. Don't re-imagine it.** Open the snippet, copy its body, paste it where it goes.
2. **Press Start 2P MUST be loaded** for any title or modal-headline copy. The Google Fonts `<link>` is in every snippet that needs it. Don't strip it.
3. **`shape-rendering="crispEdges"` on every SVG** that contains pixel-art rects. Don't drop it.
4. **`image-rendering: pixelated`** on parent containers for the CSS-DOM sprites (player, enemy, etc).
5. **No emoji** as decoration. The brand uses pixel-art SVG emblems instead.
6. **Token reference:** if your project already has `colors_and_type.css`, the tokens align (`--pw-bg`, `--pw-brand`, `--pw-gold`, `--pw-world-*`). If not, the snippets use literal hex values so they still work standalone.
