# Parkour Worlds — Iconography & World Emblems

The game ships zero raster logo, zero icon font, zero SVG library. **All visual identity is generated** — either from procedural canvas drawing, hand-pixeled rect data, system emoji rendering, or Unicode glyphs.

## World emblems

Each world has a hand-pixeled 16×16 emblem (rect data in `src/game/utils/emblems.js`) plus a fallback system emoji and an accent color. The emblem is the hero treatment; emoji are used only at tiny HUD-breadcrumb sizes.

| Pixel emblem | Emoji | World | Accent | Glyph palette |
|---|---|---|---|---|
| anchor | ⚓ | Pirate Seas | `#2196F3` | white shaft on `#9bd0ff` wave base |
| shuriken | 🥷 | Ninja Dojo | `#CE93D8` | white star points + lilac core on `#3a2440` |
| cactus | 🌵 | Wild West | `#FFCC80` | greens `#3a8c2a #6ec044 #1d5d18` on `#8b6030` sand |
| shell | 🐚 | Deep Ocean | `#80DEEA` | cream `#ffe9c2` body + cyan inner + `#ff9b6b` ridge |
| flame | 🔥 | Fire & Brimstone | `#FF7043` | `#ff3d00 → #FF7043 → #FFD700` from outer to core |
| target | 🎯 | Practice | `#aaaaaa` | red `#c62828` rings + orange + gold center |

See `preview/world-emblems.html` and `snippets/emblems.html` for the catalog and paste-ready SVG.

## Semantic Unicode

| Glyph | UTF | Meaning |
|---|---|---|
| `★` | U+2605 | Cleared / personal best |
| `☠` | U+2620 | Death counter prefix |
| `◀` | U+25C0 | Your-current-run cursor |
| `🔒` | U+1F512 | Locked content |
| `›` | U+203A | Breadcrumb separator |
| `·` | U+00B7 | Middle-dot list separator |
| `—` | U+2014 | Callout em-dash |

## Procedural pixel-sprites

See `ui_kits/parkour-worlds/PixelSprites.jsx` and `preview/components-sprites.html` / `preview/components-enemies.html` for HTML/CSS recreations of:

- **Player** — 18×26 body bounds, world-coat tinted, ten stacked rects (shoes, pants, coat, belt + gold buckle, face, eye, world-tinted hat brim + crown + highlight).
- **Coin** — 8×12 + 12×6 pixel-art diamond with a 3×3 white specular dot top-left. Tinted per world.
- **Chest** — 36×26 wood box with brass band and gold lock (level goal).
- **Checkpoint flag** — 1×40 pole + 14×11 triangular pennant. Red untriggered, green with glow halo + rising sparks when triggered.
- **Per-world enemies** (each fully unique, not just a recolor):
  - Pirate captain — tricorn hat with gold band, striped shirt, eye patch, cutlass
  - Ninja — dark gi, masked head, glowing eye slit, shuriken in hand
  - Cowboy — wide brim hat, red bandana, leather vest, revolver
  - Crab — dome body, 8 walking legs (alternating), animated claws, bobbing eyestalks
  - Rock Golem — chunky body with animated lava-crack veins, boulder arm, single pulsing lava eye
  - Default robot (Practice) — metal box body, glowing visor, antenna

Every sprite is built with `position:absolute` colored `<div>`s or `fillRect`s pinned to exact in-game coordinates. Do not redraw.
