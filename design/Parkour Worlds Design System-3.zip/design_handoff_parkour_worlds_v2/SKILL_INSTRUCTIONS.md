---
name: parkour-worlds-design
description: Use this skill to generate well-branded interfaces and assets for Parkour Worlds, a pixel-art platformer with 5 themed worlds (20 levels total) and a per-world chiptune soundtrack. Contains design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

# How to use this skill

Read `README.md` first. Then, depending on the task, **read the actual source files** instead of approximating from memory or screenshots.

## ⚠️ Hard rules — DO NOT BREAK

1. **NEVER redraw the pixel-art sprites from screenshots or memory.** Every rect coordinate is intentional and won't survive a re-imagine. If you need a sprite, COPY the SVG/CSS verbatim from one of:
   - `snippets/emblems.html` — all 6 world emblems as inline SVG (paste-ready)
   - `snippets/sprites.html` — player, diamond coin, chest, flag (paste-ready CSS-DOM)
   - `snippets/title-screen.html` — the full Main Menu scene with floating islands + two-tone title
   - `ui_kits/parkour-worlds/Emblem.jsx` — same emblems as React components
   - `ui_kits/parkour-worlds/PixelSprites.jsx` — same sprites as React components

2. **Title treatment is italic bold monospace, two-tone, with a divider.** `PARKOUR` is gold `#FFD700`, `WORLDS` is purple `#b888ff`, both `font-style: italic`. Beneath them sits a 420×2 split rule — gold on the left half, purple on the right. The shipping game uses generic `monospace` (no display font); Press Start 2P is OK on hero shots, but italic + two-tone is non-negotiable.

3. **`shape-rendering="crispEdges"` on every pixel-art SVG.** And `image-rendering: pixelated` on every container holding CSS-DOM sprites. Without these, pixels get anti-aliased and look blurry.

4. **No emoji as decoration.** The brand uses pixel-art SVG emblems for hero treatments and system emoji only as tiny breadcrumb fallbacks. Only Unicode glyphs allowed elsewhere: `★ ☠ ◀ › · —`.

5. **Color discipline:**
   - Purple `#b888ff` — brand chrome (Menu title's "WORLDS", divider right-half, panel stroke, prompt button)
   - Gold `#FFD700` — gameplay reward + Menu title's "PARKOUR" (coins, stars, personal bests, divider left-half)
   - World accents `#2196F3 #CE93D8 #FFCC80 #80DEEA #FF7043 #aaaaaa` — level chrome (HUD rail, world cards, tile edge-hi, dash trail, coin tint)
   - Void `#06060f` — World Select + HUD chrome
   - Menu sky gradient `#0c0420 → #181660` — Main Menu only

6. **Coins are pixel-art diamonds, not circles.** Two stacked rects (8×12 + 12×6) with a 3×3 white specular dot top-left. Tinted per world.

7. **20 levels, not 15.** 5 worlds × 4 levels + 1 Practice room. Anything referencing "15 levels" is stale and must be updated.

## File map

| Path | Use when |
|---|---|
| `snippets/title-screen.html`        | You need the full Main Menu scene with islands + new title. Drop-in. |
| `snippets/emblems.html`             | You need a world emblem (anchor, shuriken, cactus, shell, flame, target). |
| `snippets/sprites.html`             | You need player / diamond coin / chest / flag / enemy. |
| `preview/*.html`                    | Visual reference for any token, type style, or component. |
| `preview/components-enemies.html`   | Per-world enemy archetypes (pirate captain, ninja, cowboy, crab, golem). |
| `preview/components-islands.html`   | The floating-island building blocks for the Main Menu. |
| `preview/components-platforms-by-world.html` | Per-world tile body / edge / seam / surface decoration. |
| `preview/components-coin-dash.html` | Diamond coin + dash trail + HUD dash indicator. |
| `preview/motion-music.html`         | Per-world soundtrack spec (BPM, key, instruments). |
| `ui_kits/parkour-worlds/*.jsx`      | React component sources (Emblem, PixelSprites, WorldCard, HUD, MainMenu w/ islands…). |
| `colors_and_type.css`               | Every design token (`--pw-bg`, `--pw-brand`, `--pw-gold`, `--pw-world-*`, `--pw-tile-*`, `--pw-island-*`, `--pw-bpm-*`, etc). Import at the top of any new file. |
| `README.md`                         | Brand voice, casing, motion rules, visual foundations. |

## Defaults if the user invokes this skill bare

If the user runs the skill without context, ask:
1. Which surface? (Main Menu / World Select / in-game HUD / Complete modal / something new)
2. Which world tint? (Pirate / Ninja / West / Ocean / Fire / theme-neutral)
3. Static or interactive?

Then build to spec, copying snippets verbatim where they apply.
