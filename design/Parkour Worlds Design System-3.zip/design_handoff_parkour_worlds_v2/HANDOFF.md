# Parkour Worlds — Design System Handoff (v2)

Target codebase: [`mohitbisbey-wq/Platformer-v1`](https://github.com/mohitbisbey-wq/Platformer-v1) — Phaser 4 + webpack pixel-art platformer.

## What this bundle is

The HTML files in this package are **design references**, not production code. They mock up the intended look + behavior of every screen, sprite, and token in the Parkour Worlds design system. The developer's job is to **port these specs to the actual Phaser game source** (`src/game/scenes/*.js`, `src/game/utils/*.js`, `src/game/data/worlds.js`). Most of the system already lives there — this bundle locks down what V2 adds and what changed since V1.

## Fidelity

**High-fidelity.** Every color hex, sprite pixel coord, font size, BPM, animation duration, and timing constant in these files is final and should be transferred verbatim. Sprite pixel rect data is paste-ready (see `snippets/sprites.html`, `snippets/emblems.html`).

## What's new in V2

| Area | Change | Where to look |
|---|---|---|
| **Main Menu** | Italic two-tone title (`PARKOUR` gold + `WORLDS` purple), nebula sky, crescent moon, drifting pixel clouds, 5 floating world-islands with hanging-root dirt, ground emblem-strip | `preview/brand-title.html` · `ui_kits/parkour-worlds/index.html` · `src/game/scenes/MainMenu.js` |
| **Clockwork world (6th)** | New brass-tinted unlockable world with cog emblem, `#B8783F` accent, brass-rivet platform tiles, music-box chiptune in A minor @ 84 BPM | `preview/colors-platforms.html` · `preview/components-islands.html` · `preview/motion-music.html` |
| **Per-world enemies** | 6 unique sprites (Pirate captain, Ninja, Cowboy, Crab, Rock Golem, Robot) — NOT recolors | `preview/components-enemies.html` · `preview/components-sprites.html` · `src/game/scenes/Game.js` `_sprPirate/_sprNinja/...` |
| **Per-world tile palette** | 7-color tile system per world (body / edgeHi / edgeSub / seam / inner / surf / coat) + surface decoration | `preview/components-platforms-by-world.html` · `WC[]` in `Game.js` |
| **Dash mechanic** | `Shift`/`Z` dash, 12-frame burst, 7-frame world-accent trail, HUD diamond indicator | `preview/components-coin-dash.html` · `_physicsUpdate` in `Game.js` |
| **Diamond coins** | Were circles, now pixel-art diamonds (8×12 + 12×6 + 3×3 spec) per-world tinted | `preview/components-coin-dash.html` · `_drawCoins` in `Game.js` |
| **Music system** | Procedural Web Audio chiptune per world (no audio files) | `preview/motion-music.html` · `src/game/utils/music.js` |
| **Level count** | 20 total (5 worlds × 4) + Practice + Clockwork = 24 with Clockwork landed | `worlds.js`, `WorldSelect.js` |

## Quick reference: design tokens

All tokens live in `colors_and_type.css` as CSS custom properties. Key signals:

- `--pw-brand: #b888ff` — brand purple (title chrome, menu rail, prompt button)
- `--pw-gold: #FFD700` — earned/reward gold (coins, stars, personal bests, "PARKOUR" half of title)
- `--pw-bg: #06060f` — void chrome (World Select + HUD)
- `--pw-menu-sky-top: #0c0420` / `--pw-menu-sky-bot: #181660` — Main Menu twilight gradient

World accents (5 + Clockwork + Practice):

```
#2196F3  Pirate Seas        ⚓ anchor
#CE93D8  Ninja Dojo         🥷 shuriken
#FFCC80  Wild West          🌵 cactus
#80DEEA  Deep Ocean         🐚 shell
#FF7043  Fire & Brimstone   🔥 flame
#B8783F  Clockwork          ⚙️ cog            ← NEW
#aaaaaa  Practice           🎯 target
```

Per-world tile palettes (7 colors each) are tokenized as `--pw-tile-{1-5,x}-{coat|hat|body|edge-hi|edge-sub|seam|inner|surf}` plus a new `--pw-tile-6-*` set for Clockwork (see `colors_and_type.css`).

## Layout reference

- Canvas: 800 × 450, `pixelArt: true`, 8 px rounded corners
- HUD bar: 38 px tall, 3 zones: `[emoji + world › level]` left, `[dash diamond | timer | coin]` center, `[☠ deaths · ESC = menu]` right, mute speaker bottom-right
- World cards: 136 × 316, 13 px gap, 1.5 px stroke, 4 px top color rail
- Complete modal: 392 × 292, gold halo `rgba(255,215,0,.30)` stroke

## Sprites — paste-ready

These are 1:1 with the in-engine rect data. Copy verbatim — do NOT re-imagine from screenshots.

- `snippets/sprites.html` — player (18×26 five-rect stack), diamond coin, chest, checkpoint flag
- `snippets/emblems.html` — 6 world emblems as inline SVG with `shape-rendering="crispEdges"`
- `ui_kits/parkour-worlds/PixelSprites.jsx` — React component versions (for the UI kit demo)
- `preview/components-sprites.html` — base sprites + per-world enemy catalog
- `preview/components-enemies.html` — full per-world enemy detail

## Music spec (per world)

Procedural Web Audio — `src/game/utils/music.js`. Look-ahead 16th-note scheduler.

| Scene | Key | BPM | Voice stack |
|---|---|---|---|
| Main Menu | D maj | 100 | triangle melody + sine bass + 3-voice sine pad + kick/snare |
| Pirate Seas | D maj | 124 | sine bass + triangle melody + kick/snare/hat |
| Ninja Dojo | D min pent | 72 | triangle pluck + sine drone + bell |
| Wild West | E maj pent | 92 | sawtooth + harmonic + gallop hat |
| Deep Ocean | F minor | 50 | sine pads + sub bass + bubbles |
| Fire & Brimstone | E minor | 158 | sawtooth bass + square lead + double kick + sub |
| **Clockwork** | **A minor** | **84** | **triangle bell + sine bass + hi-pass ticks (tick-tock)** ← NEW |
| Practice | C major | 100 | square + sine + kick/snare |

## File map

| Path | What it documents |
|---|---|
| `HANDOFF.md` | This file. |
| `BRAND_GUIDE.md` | Brand voice, casing, visual foundations, layout rules. |
| `SKILL_INSTRUCTIONS.md` | Skill manifest (`parkour-worlds-design`) for using this system with Claude Code. |
| `colors_and_type.css` | All design tokens — colors, type scale, spacing, radii, motion, music BPM. |
| `assets/ICONOGRAPHY.md` | Emblem catalog + semantic Unicode glyphs. |
| `preview/` | 23 visual reference cards — one per token group or component. |
| `snippets/` | Paste-ready HTML fragments (title screen, emblems, sprites). |
| `ui_kits/parkour-worlds/` | Interactive React/JSX recreation of Main Menu, World Select, in-game HUD, Level Complete modal. Open `index.html` to demo. |

## Implementation order (suggested)

1. **Tokens first** — port `colors_and_type.css` values into your game's color/font constants (`Game.js` `WC[]`, `MainMenu.js` `ISLAND_GRASS/DIRT`, music BPMs). The CSS layer here is for the design system; the engine layer is `parseInt('#...', 16)` literals in JS.
2. **Main Menu refresh** — rebuild `MainMenu.js` from `preview/brand-title.html`. Italic title, divider, panel, 6 islands (with Clockwork), nebulae, moon, drifting clouds.
3. **Clockwork world data** — add `WD[6]` (or `WD[5]` with Practice shifted) in `worlds.js` with 4 levels. Update `WorldSelect.js` to render 6 cards.
4. **Per-world enemies** — `_sprClockwork()` in `Game.js` for the new world; the 5 existing per-world enemy functions are already present.
5. **Music** — add `_clockwork(ac, d)` to `music.js`. A minor pentatonic, 84 BPM, triangle bell melody, sine bass, hi-pass ticks every 8th note for tick-tock.
6. **Wiring** — `Game.js` `WC[5]` slot for Clockwork tile palette (see `--pw-tile-6-*` tokens), `emblems.js` `cog` rect data (see `preview/brand-iconography.html`).

## Things NOT to do

- **Don't redraw sprites from screenshots.** Every coord is intentional.
- **Don't add icon libraries** (no Lucide, Material, Heroicons, FontAwesome). The brand has rejected icon fonts implicitly.
- **Don't use emoji as decoration.** Emoji = brand emblem fallback at tiny sizes only. Pixel-art emblems are the hero.
- **Don't add backdrop-filter blur** on the complete modal — it's pure `rgba(0,0,0,.75)` scrim.
- **Don't gradient text** the title — solid colors only, two-tone split.
- **Don't substitute the title font with anything that isn't bold italic monospace.** Press Start 2P is an opinionated alternate for hero shots, but the engine uses generic `monospace`.

## Open questions / latest user-requested tweaks

These are recent design-review decisions that may or may not be in the latest `MainMenu.js`/`Game.js`:

- Main Menu title: user wanted both halves purple in the design-system preview (`preview/brand-title.html`), but the engine still ships gold + purple. Confirm intent before changing engine.
- Elevation halo: user moved the "earned" pulse color from gold (`#FFD700`) to deep purple (`#7d3df0`) — see `preview/spacing-elevation.html`. This is design-system only; in-engine completion pulse is still gold.
- Type Display card: user moved "PARKOUR" half from gold to dark blue `#2540A8` — see `preview/type-display.html`. Again, design-system only.

When in doubt, the in-engine canvas demo `public/parkour-worlds.html` is the source-of-truth visual reference; this design system formalizes it.
